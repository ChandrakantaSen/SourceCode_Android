// NameThatThread.java
class thread1
{
   public static void main (String [] args)
   {
      MyThread2 mt;
      if (args.length == 0)
          mt = new MyThread2 ();
      else
          mt = new MyThread2 (args [0]);
      mt.start ();
   }
}
class MyThread2 extends Thread
{
   MyThread2 ()
   {
      // The compiler creates the byte code equivalent of super ();
   }
   MyThread2 (String name)
   {
      super (name); // Pass name to Thread superclass
   }
   public void run ()
   {
      System.out.println ("My name is: " + getName ());
   }
}