
class thread2 {
   public static void main(String args[]) {
      new NewThread2();  

      //Slow Work
   }
}

class NewThread2 implements Runnable {
   Thread t;
   NewThread2() {
      t = new Thread(this, "Demo Thread"); // Thread()    Thread("SimpleThread");  Thread(this, "Demo Thread")
      t.start(); 
   }
   
   public void run() {
      ///Slow Work.
	  System.out.println("Test "+Thread.currentThread().getName());
   }
}
