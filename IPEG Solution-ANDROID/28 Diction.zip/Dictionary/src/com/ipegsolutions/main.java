package com.ipegsolutions;
import java.io.*;

import android.view.View;
import android.widget.*;
import java.net.URL;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class main extends Activity implements View.OnClickListener {
	ImageButton btn, info, exit;
	EditText et;
    /** Called when the activity is first created. */
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        et = (EditText) findViewById (R.id.edit);
        btn = (ImageButton) findViewById (R.id.btn);
        btn.setOnClickListener(this);
        info = (ImageButton) findViewById (R.id.info);
        info.setOnClickListener(this);
        exit = (ImageButton) findViewById (R.id.exit);
        exit.setOnClickListener(this);
    }
  
    @Override
    public void onClick (View v)
    {
    	if(v.equals(btn))
    	{
    	///////////////////////////////////
    	
        Intent intent = new Intent(main.this,result.class); //Ignore error
 		
 		Bundle bundle = new Bundle();
    	bundle.putString("WORD",et.getText().toString().trim());

    	intent.putExtras(bundle);
    	 
 		main.this.startActivity(intent);
 		/////////////////////////////////////////
    	}
    	if (v.equals(exit))
    			{
    			finish();
    			}
    	if (v.equals(info))
    	{
    		 Intent intent = new Intent(main.this,info.class); //Ignore error
    	 	//  	    	intent.putExtras(bundle);
      	 	main.this.startActivity(intent);
    	}
 	
    }
}