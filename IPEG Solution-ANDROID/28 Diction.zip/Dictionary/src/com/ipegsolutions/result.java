package com.ipegsolutions;
import java.io.*;

import android.view.View;
import android.widget.*;

import java.net.URL;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class result extends Activity implements View.OnClickListener {
    /** Called when the activity is first created. */
	ImageButton back;
	  
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inside);
        back = (ImageButton) findViewById (R.id.back);
        back.setOnClickListener(this);
    
        
        Bundle bundle = getIntent().getExtras();
		String word = bundle.getString("WORD");
	    
       String x = download("http://oxforddictionaries.com/search/?region=uk&direct=1&q="+word);
	   String meaning = getMeaning(x);
       
       TextView tv = (TextView) findViewById (R.id.tv);
       tv.setText(word+" means: \n\n"+meaning);
		
    }
  
    public static String download(String myURL)
	{
		String output = "";	//String myURL = "http://www.google.com";
		//////////////////////////////////////////////////////////////////////////
	try{
		//Write to Temp File
			BufferedInputStream in = new BufferedInputStream(new URL(myURL).openStream());
			FileOutputStream fos = new FileOutputStream("/data/data/com.ipegsolutions/temp.html");
			BufferedOutputStream bout = new BufferedOutputStream(fos,1024);			
			byte[] data = new byte[1024];
			int x=0; 
			while((x=in.read(data,0,1024))>=0)
			{
				bout.write(data,0,x);
			}		
			bout.close();
			in.close();
		//Read into a string
	
			FileInputStream fstream;
			DataInputStream dis;
			fstream = new FileInputStream("/data/data/com.ipegsolutions/temp.html");
			dis = new DataInputStream(fstream);
			while (dis.available()!= 0)
			{
				output += dis.readLine();
			}
		///////////////////////////////////////////////////////////////////////////	
	}
	catch (IOException e)	{	}
			return output;
	}
    public static String getMeaning(String html)
	{
		String[] arr = html.split("<span class=\"definition\">");
		String[] arr2 = arr[1].split("</span>");
		return arr2[0];
	} 
    
    @Override
    public void onClick (View v)
    {
    
    	if (v.equals(back))
    	{
    		finish();
    		//  		 Intent intent = new Intent(result.this,main.class); //Ignore error
      	 	//result.this.startActivity(intent);
    	}
 	
    }
}