package com.ipegsolutions;
import java.io.*;

import android.view.View;
import android.widget.*;

import android.widget.*;
import java.net.URL;
import org.apache.http.HttpResponse;
import org.apache.http.client.HttpClient;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.impl.client.DefaultHttpClient;
import org.apache.http.protocol.BasicHttpContext;
import org.apache.http.protocol.HttpContext;
import android.view.View;
import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;

public class info extends Activity  implements View.OnClickListener  {
    /** Called when the activity is first created. */
	ImageButton back;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.inside);
        back = (ImageButton) findViewById (R.id.back);
        back.setOnClickListener(this);
        
       TextView tv = (TextView) findViewById (R.id.tv);
       tv.setText(" Dictionary App. Made by FreshersIndia...........  ");
		
    }
  
    @Override
    public void onClick (View v)
    {
    
    	if (v.equals(back))
    	{
    		finish();
    		// Intent intent = new Intent(info.this,main.class); //Ignore error
      	 	//info.this.startActivity(intent);
    	}
 	
    }
}