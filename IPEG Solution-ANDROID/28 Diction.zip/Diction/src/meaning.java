import java.io.*;
import java.net.URL;
class meaning
{
	
	public static void main(String[] a) throws IOException
	{
		
		System.out.println("Please enter a word");
		BufferedReader br = new BufferedReader(new InputStreamReader(System.in));
		try {
			String user = br.readLine();
			String x = download("http://oxforddictionaries.com/search/?region=uk&direct=1&q="+user);
			String meaning = getMeaning(x);
			
			System.out.print("The meaning of "+user+" is "+meaning);
		}
		catch (IOException e)
		{
			
		}				
	}
	
	public static String getMeaning(String html)
	{
		String[] arr = html.split("<span class=\"definition\">");
		String[] arr2 = arr[1].split("</span>");
		return arr2[0];
	}
	
	public static String download(String myURL)
	{
		String output = "";	//String myURL = "http://www.google.com";
		//////////////////////////////////////////////////////////////////////////
	try{
		//Write to Temp File
			BufferedInputStream in = new BufferedInputStream(new URL(myURL).openStream());
			FileOutputStream fos = new FileOutputStream("temp.html");
			BufferedOutputStream bout = new BufferedOutputStream(fos,1024);			
			byte[] data = new byte[1024];
			int x=0;
			while((x=in.read(data,0,1024))>=0)
			{
				bout.write(data,0,x);
			}		
			bout.close();
			in.close();
		//Read into a string
	
			FileInputStream fstream;
			DataInputStream dis;
			fstream = new FileInputStream("temp.html");
			dis = new DataInputStream(fstream);
			while (dis.available()!= 0)
			{
				output += dis.readLine();
			}
		///////////////////////////////////////////////////////////////////////////	
	}
	catch (IOException e)	{	}
			return output;
	}
}



