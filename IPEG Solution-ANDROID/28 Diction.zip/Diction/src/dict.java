import java.io.*;
import java.net.*;

//Perfect!!
public class dict
{
	public static void main(String args[]) throws IOException
	{
		String user,meaning;
		System.out.println("Enter a word");
		BufferedReader br = new BufferedReader ( new InputStreamReader (System.in));
		try {
		 user = br.readLine();	
		}
		catch (IOException e)
		{
		user = "Hello";
		}
		
	String html = download ("http://dictionary.cambridge.org/search/british/direct/?q="+user);
	String[] arr = html.split("<span class=\"def parentof__def__is__sense_b\">");
	if(arr.length>1)
	{
	String arr2[] =  arr[1].split("</span>");
	meaning = arr2[0];
	}
	else
		 meaning = "Problem";
	System.out.println( meaning);	
	}
	static String download (String myURL) throws IOException
	{
		BufferedInputStream in = new BufferedInputStream(new 
		URL(myURL).openStream());
		FileOutputStream fos = new FileOutputStream("temporary");
		BufferedOutputStream bout = new BufferedOutputStream(fos,1024);			
		byte[] data = new byte[1024];
		int x=0;
		while((x=in.read(data,0,1024))>=0)
		{
			bout.write(data,0,x);
		}		
		bout.close();
		in.close();
		
		///////////////////////////////////////////////////////////////////////
		FileInputStream fstream = new FileInputStream("temporary");
	    DataInputStream in2 = new DataInputStream(fstream);
        String S="";
        while (in2.available() !=0)
	        	{
		    	S+=in2.readLine();
   		   }
		///////////////////////////////////////////////////////////////////////
		return S;
	}
}