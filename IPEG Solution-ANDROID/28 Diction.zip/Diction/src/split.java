class split
{
	public static void main (String[] x)
	{
		String str = "This is an example statement";
		String[] arr = str.split("e");
		
		for(int i=0; i<arr.length; i++)
		{
			System.out.println(arr[i]);
		}
	}
}