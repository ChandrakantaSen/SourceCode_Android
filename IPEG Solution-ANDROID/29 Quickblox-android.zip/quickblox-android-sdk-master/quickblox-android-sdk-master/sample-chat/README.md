## QuickBlox Android XMPP Chat Sample

Go to project page on QuickBlox Developers Section -- <http://quickblox.com/developers/Android_XMPP_Chat_Sample>

Or clone project here and start to work with the code.

<img src="http://i.imgur.com/kEtqF.png" width=180 />&nbsp;<img src="http://i.imgur.com/DdQWw.png" width=180 />&nbsp;<img src="http://i.imgur.com/yWrv5.png" width=180 />&nbsp;<img src="http://i.imgur.com/gcfyh.png" width=180 />

Video demo -- <http://www.youtube.com/watch?feature=player_embedded&v=VKsIhxMaRlE>