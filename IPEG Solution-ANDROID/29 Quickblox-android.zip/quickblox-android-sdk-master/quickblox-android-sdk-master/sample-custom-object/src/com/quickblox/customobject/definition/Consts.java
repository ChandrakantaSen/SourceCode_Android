package com.quickblox.customobject.definition;

/**
 * Created with IntelliJ IDEA.
 * User: android
 * Date: 03.12.12
 * Time: 9:06
 */
public interface Consts {
    public static final String STATUS_NEW = "New";
    public static final String STATUS_IN_PROCESS = "In Process";
    public static final String STATUS_DONE = "Done";
    public static final String NOTE_ID = "id";
    public static final String CLASS_NAME = "note";
    public static final String TITLE = "title";
    public static final String STATUS = "status";
    public static final String COMMENTS = "comments";
}
