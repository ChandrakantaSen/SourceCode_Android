package com.quickblox.customobject.definition;

/**
 * Created with IntelliJ IDEA.
 * User: android
 * Date: 30.11.12
 * Time: 16:14
 * To change this template use File | Settings | File Templates.
 */
public enum QBQueries {

    SIGN_IN,
    GET_NOTE_LIST,
    UPDATE_STATUS,
    ADD_NEW_COMMENT,
    DELETE_NOTE,
    CREATE_NOTE
}
