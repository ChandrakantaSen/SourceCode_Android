package com.quickblox.simplesample.messages.main.definitions;

public class Consts {
    //
    // In GCM, the Sender ID is a project ID that you acquire from the API console
    public static String GSM_SENDER = "761750217637";
}
