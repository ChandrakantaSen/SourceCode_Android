package com.quickblox.sample.user.definitions;

/**
 * Created with IntelliJ IDEA.
 * User: android
 * Date: 20.11.12
 * Time: 12:28
 */
public enum QBQueries {

        QB_QUERY_AUTHORIZE_APP,
        QB_QUERY_GET_ALL_USERS,
        QB_QUERY_CREATE_QB_USER,
        QB_QUERY_SIGN_IN_QB_USER,
        QB_QUERY_LOG_OUT_QB_USER,
        QB_QUERY_UPDATE_QB_USER,
        QB_QUERY_DELETE_QB_USER
}
