package com.quickblox.sample.user.definitions;

/**
 * Created with IntelliJ IDEA.
 * User: android
 * Date: 20.11.12
 * Time: 14:43
 */
public interface Consts {

    public static final String APP_ID = "99";
    public static final String AUTH_KEY = "63ebrp5VZt7qTOv";
    public static final String AUTH_SECRET = "YavMAxm5T59-BRw";
    public static final String POSITION = "position";
    public static final String EMPTY_STRING = "";

}
