package com.quickblox.ratings.main.definitions;

/**
 * Created with IntelliJ IDEA.
 * User: android
 * Date: 29.11.12
 * Time: 10:06
 * To change this template use File | Settings | File Templates.
 */
public enum QBQueries {
    GET_AVARAGE_FOR_GAME_MODE,
    SIGN_IN,
    CREATE_SCORE,
}
