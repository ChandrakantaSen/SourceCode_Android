package com.freshersindia;

import android.app.Activity;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.TextView;

public class main extends Activity {
    /** Called when the activity is first created. */
	TextView tv;
    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.main);
        
        //READ A VALUE 
         SharedPreferences app_preferences = PreferenceManager.getDefaultSharedPreferences(this);
        int x  = app_preferences.getInt("mycounter", 1);     
         
        tv = (TextView)findViewById(R.id.tv);
       
        tv.setText("You have run me "+ x + " times. ");
        
        
        //SET A VALUE
        SharedPreferences.Editor editor = app_preferences.edit();  
        int y = ++x;    
        editor.putInt("mycounter", y );    
        editor.commit(); // Very important
   
    }
}